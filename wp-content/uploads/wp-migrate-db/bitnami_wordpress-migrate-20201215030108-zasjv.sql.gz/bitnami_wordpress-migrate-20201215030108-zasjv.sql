# WordPress MySQL database migration
#
# Generated: Tuesday 15. December 2020 03:01 UTC
# Hostname: localhost:3306
# Database: `bitnami_wordpress`
# URL: //stizzthawizz.github.io/ymyd/
# Path: C:\\wamp64\\www\\ymyd/
# Tables: 
# Table Prefix: wp_
# Post Types: revision, attachment, bauman_portfolio, custom_css, customize_changeset, elementor_library, gr_redirect, nav_menu_item, ngg_gallery, ngg_pictures, oembed_cache, page, post, product, product_variation, robo_gallery_table, shop_order, tablepress_table, wp_block, wpcf7_contact_form
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

